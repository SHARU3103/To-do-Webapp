package com.Controller;

import java.io.IOException;
import java.sql.Connection;

import com.ConnectionFactory.ConnectionFactory;
import com.Dao.UserDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/login")
public class Launch2 extends HttpServlet
{
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userid = req.getParameter("userid");
		String password = req.getParameter("password");
		
		Connection con = ConnectionFactory.getCon();
		UserDao uDao = new UserDao();
		
		String res=uDao.checkUser(userid, password, con);
		HttpSession session = req.getSession();
		
		if(res.equals("exists"))
		{
			
			session.setAttribute("check", userid);
			resp.sendRedirect("home.jsp");
		}
		else
		{
			session.setAttribute("msg", "Invalid credential");
			resp.sendRedirect("login.jsp");
		}
	}
}
