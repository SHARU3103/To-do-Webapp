package com.Dao;

import java.sql.Connection;
import java.sql.Statement;

public class NotesDao {
	
	public void createNoteTable(String userid, Connection con)
	{
		try
		{
			String sql = "create table "+userid+"notes(notedes varchar(255), adddate varchar(50), editDate varchar(50))";
			Statement st = con.createStatement();
			st.execute(sql);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}

}
